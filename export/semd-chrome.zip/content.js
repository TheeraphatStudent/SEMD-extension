(()=>{function k(e){return Boolean(e&&e.runtime&&typeof e.runtime.sendMessage==="function"&&e.runtime.onMessage&&typeof e.runtime.onMessage.addListener==="function")}function A(){let e=typeof browser<"u"?browser:void 0,t=typeof chrome<"u"?chrome:void 0,n=k(e)?e:k(t)?t:void 0;if(!n)throw Error("Browser extension APIs are unavailable");return n}var v="semd-warning-overlay",S="semd-warning-root";var N=["about:","chrome:","chrome-extension:","edge:","file:","moz-extension:","opera:","view-source:"],i={getExtensionState:"GET_EXTENSION_STATE",getActiveTab:"GET_ACTIVE_TAB",evaluateUrl:"EVALUATE_URL",getSettings:"GET_SETTINGS",updateSettings:"UPDATE_SETTINGS",validateAccessCode:"VALIDATE_ACCESS_CODE",clearAccessCode:"CLEAR_ACCESS_CODE",continueToUrl:"CONTINUE_TO_URL",goBackFromWarning:"GO_BACK_FROM_WARNING",dismissWarning:"DISMISS_WARNING",stateUpdated:"STATE_UPDATED"};function a(e){try{let t=new URL(e);return t.hash="",t.toString()}catch{return e.trim()}}function _(e){try{return new URL(e).hostname}catch{return""}}function c(e){try{let t=new URL(e).protocol;return N.includes(t)}catch{return!0}}function w(e){try{let t=new URL(e).protocol;return t==="http:"||t==="https:"}catch{return!1}}function p(){document.getElementById(v)?.remove()}function C(e,t,n={}){p();let r=_(e)||e,o=document.createElement("div");o.id=v,o.setAttribute("role","dialog"),o.setAttribute("aria-modal","true"),o.tabIndex=-1;let R=o.attachShadow({mode:"open"}),x=document.createElement("style");x.textContent=`
    :host { all: initial; }
    *, *::before, *::after { box-sizing: border-box; }
    .backdrop {
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      display: grid;
      place-items: center;
      background: rgba(20, 18, 27, 0.72);
      padding: 20px;
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    .panel {
      width: min(100%, 420px);
      border-radius: 24px;
      padding: 24px;
      background: linear-gradient(180deg, #fff5f4 0%, #ffffff 100%);
      border: 1px solid rgba(191, 77, 55, 0.2);
      box-shadow: 0 24px 80px rgba(32, 18, 18, 0.28);
      color: #271a19;
    }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      border-radius: 999px;
      background: #ffe0db;
      color: #a73f2b;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }
    h1 {
      margin: 16px 0 8px;
      font-size: 28px;
      line-height: 1.1;
    }
    p {
      margin: 0;
      color: #705654;
      line-height: 1.5;
      font-size: 14px;
    }
    .host {
      margin: 18px 0;
      padding: 14px 16px;
      border-radius: 16px;
      background: #ffffff;
      border: 1px solid rgba(191, 77, 55, 0.16);
      font-weight: 700;
      word-break: break-word;
    }
    .actions {
      display: grid;
      gap: 10px;
      margin-top: 20px;
    }
    button {
      appearance: none;
      border: none;
      border-radius: 16px;
      min-height: 48px;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
      transition: transform 150ms ease, opacity 150ms ease, box-shadow 150ms ease;
    }
    button:focus-visible {
      outline: 3px solid rgba(121, 158, 255, 0.5);
      outline-offset: 2px;
    }
    button:hover { transform: translateY(-1px); }
    .primary {
      background: #bf4d37;
      color: white;
      box-shadow: 0 12px 24px rgba(191, 77, 55, 0.24);
    }
    .secondary {
      background: #fff;
      color: #6d4f4c;
      border: 1px solid rgba(191, 77, 55, 0.16);
    }
    .dismiss {
      background: transparent;
      color: #8e7471;
    }
    @media (prefers-reduced-motion: reduce) {
      button { transition: none; }
    }
  `;let u=document.createElement("div");u.id=S,u.className="backdrop";let f=document.createElement("div");f.className="panel";let h=document.createElement("div");h.className="badge",h.textContent="SEMD Warning";let y=document.createElement("h1");y.textContent="This website may be dangerous";let U=document.createElement("p");U.textContent="SEMD detected a potentially malicious destination. Going back is recommended unless you trust this address.";let E=document.createElement("div");E.className="host",E.textContent=r;let b=document.createElement("div");b.className="actions";let s=document.createElement("button");s.className="primary",s.textContent=n.goBackText??"Go back";let d=document.createElement("button");d.className="secondary",d.textContent=n.continueText??"Continue anyway";let l=document.createElement("button");l.className="dismiss",l.textContent=n.dismissText??"Dismiss",b.append(s,d,l),f.append(h,y,U,E,b),u.append(f),R.append(x,u),document.documentElement.append(o);let L=document.activeElement;function m(){p(),L?.focus?.()}s.addEventListener("click",()=>{m(),t.onGoBack()}),d.addEventListener("click",()=>{m(),t.onContinue()}),l.addEventListener("click",()=>{m(),t.onDismiss()}),o.addEventListener("keydown",(T)=>{if(T.key==="Escape")T.preventDefault(),m(),t.onDismiss()}),s.focus()}var g=A();class O{currentUrl="";observer=null;warningUrl="";blockedNavigationUrl=null;init(){this.currentUrl=a(window.location.href),this.evaluateCurrentUrl("page_load"),this.startUrlMonitor(),this.attachNavigationGuards()}async evaluateCurrentUrl(e){let t=a(window.location.href);if(!t||c(t))return;this.currentUrl=t;let n=await this.sendEvaluation(t,e);if(!n.ok)return;this.applyEvaluation(n.data,t)}async sendEvaluation(e,t){return new Promise((n)=>{g.runtime.sendMessage({type:i.evaluateUrl,payload:{url:e,tabId:void 0,trigger:t}},(r)=>{if(g.runtime.lastError){n({ok:!1,error:{code:"message_failed",message:g.runtime.lastError.message}});return}n(r)})})}applyEvaluation(e,t){if(e.status==="malicious"){this.warningUrl=t;let n=e.trigger==="pre_navigation";this.blockedNavigationUrl=n?t:null,C(t,{onContinue:()=>{if(this.blockedNavigationUrl){let r=this.blockedNavigationUrl;this.blockedNavigationUrl=null,this.sendAction(i.continueToUrl,{url:r});return}this.sendAction(i.dismissWarning)},onGoBack:()=>{if(this.blockedNavigationUrl=null,n){this.sendAction(i.dismissWarning);return}this.sendAction(i.goBackFromWarning)},onDismiss:()=>{this.blockedNavigationUrl=null,this.sendAction(i.dismissWarning)}},n?{goBackText:"Stay here"}:void 0);return}if(this.warningUrl===t)this.warningUrl="",this.blockedNavigationUrl=null,p()}async sendAction(e,t){return new Promise((n)=>{g.runtime.sendMessage(t?{type:e,payload:t}:{type:e},()=>n())})}startUrlMonitor(){window.addEventListener("popstate",()=>void this.onUrlChange()),window.addEventListener("hashchange",()=>void this.onUrlChange());let e=history.pushState.bind(history),t=history.replaceState.bind(history);if(history.pushState=(...n)=>{e(...n),this.onUrlChange()},history.replaceState=(...n)=>{t(...n),this.onUrlChange()},this.observer=new MutationObserver(()=>{if(a(window.location.href)!==this.currentUrl)this.onUrlChange()}),document.documentElement)this.observer.observe(document.documentElement,{childList:!0,subtree:!0})}async onUrlChange(){let e=a(window.location.href);if(e===this.currentUrl)return;this.currentUrl=e,await this.evaluateCurrentUrl("navigation")}attachNavigationGuards(){document.addEventListener("click",(e)=>{let n=e.target?.closest("a[href]");if(!n)return;let r=n.href;if(!w(r)||c(r))return;if(n.target==="_blank"||e.metaKey||e.ctrlKey||e.shiftKey)return;e.preventDefault(),this.guardNavigation(r,()=>{window.location.href=r})},!0),document.addEventListener("submit",(e)=>{let t=e.target;if(!t?.action||!w(t.action)||c(t.action))return;e.preventDefault(),this.guardNavigation(t.action,()=>{t.submit()})},!0)}async guardNavigation(e,t){let n=await this.sendEvaluation(e,"pre_navigation");if(!n.ok){t();return}let r=n.data;if(r.status==="malicious"){this.applyEvaluation(r,e);return}t()}}if(!c(window.location.href)){let e=new O;if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",()=>e.init(),{once:!0});else e.init()}})();
