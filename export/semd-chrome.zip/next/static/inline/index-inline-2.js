self.__next_f.push([1,"3:I[3728,[],\"\"]\n5:I[9928,[],\"\"]\n6:I[6954,[],\"\"]\n7:I[7264,[],\"\"]\n9:I[8038,[\"931\",\"static/chunks/app/page-5fa18aeaaa718eac.js\"],\"PopupApp\"]\n"])
