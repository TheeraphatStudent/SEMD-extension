self.__next_f.push([1,""])
