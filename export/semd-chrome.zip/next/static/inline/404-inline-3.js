self.__next_f.push([1,"t\":400,\"lineHeight\":\"49px\",\"margin\":0}\n"])
