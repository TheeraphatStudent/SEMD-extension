self.__next_f.push([1,"1:HL[\"/next/static/css/f8e0b8ac344dd685.css\",\"style\",{\"crossOrigin\":\"\"}]\n0:\"$L2\"\n"])
