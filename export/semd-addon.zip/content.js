"use strict";(()=>{var S=()=>{if(typeof browser<"u")return browser;if(typeof chrome<"u")return chrome;throw new Error("No browser extension API available")},c=S(),l={sendMessage:(t,e)=>{e?c.runtime.sendMessage(t,e):c.runtime.sendMessage(t)},onMessage:{addListener:t=>{c.runtime.onMessage.addListener(t)}},onInstalled:{addListener:t=>{c.runtime.onInstalled.addListener(t)}},getLastError:()=>c.runtime.lastError};var g="semd-warning-overlay",p={LOGIN_TITLE:"Login",LOGIN_PROMPT:"\u0E01\u0E23\u0E2D\u0E01 Access code \u0E08\u0E32\u0E01\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E0B\u0E15\u0E4C:",LOGIN_BUTTON:"\u0E40\u0E02\u0E49\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19",SAFE:"\u0E1B\u0E25\u0E2D\u0E14\u0E20\u0E31\u0E22",DANGER:"\u0E2D\u0E31\u0E19\u0E15\u0E23\u0E32\u0E22",OVERLAY_QUESTION:"\u0E04\u0E38\u0E13\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E40\u0E02\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E0B\u0E15\u0E4C",OVERLAY_PROCEED:"\u0E43\u0E0A\u0E48, \u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D",OVERLAY_CLOSE:"\u0E44\u0E21\u0E48, \u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E0B\u0E15\u0E4C\u0E19\u0E35\u0E49",SETTINGS_TITLE:"\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32",DASHBOARD_TITLE:"\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E41\u0E01\u0E19"},i={CREAM_BG:"#FFF9E6",GOLD_ACCENT:"#F5D76E",GOLD_BORDER:"#C4A84B",SAFE_GREEN:"#4CAF50",SAFE_GREEN_DARK:"#388E3C",DANGER_RED:"#F44336",DANGER_RED_DARK:"#D32F2F",DANGER_PINK_BG:"#FFEBEE",SAFE_GREEN_BG:"#E8F5E9"};function v(t){let{url:e,accuracy:r,onProceed:o,onClose:n}=t,a=document.createElement("div");a.id=g,a.innerHTML=`
    <div style="
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(244, 67, 54, 0.2);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Noto Sans Thai', sans-serif;
    ">
      <div style="
        background: white;
        border-radius: 16px;
        padding: 32px 40px;
        max-width: 420px;
        width: 90%;
        text-align: center;
        box-shadow: 0 8px 32px rgba(0,0,0,0.25);
      ">
        <!-- Shield Icon with ? -->
        <div style="
          width: 80px;
          height: 80px;
          margin: 0 auto 20px;
          background: ${i.DANGER_RED};
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L4 6V12C4 16.42 7.4 20.74 12 22C16.6 20.74 20 16.42 20 12V6L12 2Z" fill="white" fill-opacity="0.3"/>
            <text x="12" y="16" text-anchor="middle" fill="white" font-size="14" font-weight="bold">!</text>
          </svg>
        </div>

        <!-- Warning Text -->
        <p style="
          font-size: 18px;
          color: #333;
          margin: 0 0 12px 0;
          font-weight: 500;
        ">${p.OVERLAY_QUESTION}</p>

        <!-- URL Display -->
        <p style="
          font-size: 14px;
          color: ${i.DANGER_RED};
          margin: 0 0 8px 0;
          word-break: break-all;
          text-decoration: underline;
        ">${e}</p>

        <!-- Accuracy -->
        <p style="
          font-size: 12px;
          color: #666;
          margin: 0 0 24px 0;
        ">\u0E04\u0E27\u0E32\u0E21\u0E41\u0E21\u0E48\u0E19\u0E22\u0E33: ${(r*100).toFixed(1)}%</p>

        <!-- Buttons -->
        <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
          <button id="semd-overlay-proceed" style="
            background: transparent;
            color: ${i.DANGER_RED};
            border: 2px solid ${i.DANGER_RED};
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
          ">${p.OVERLAY_PROCEED}</button>

          <button id="semd-overlay-close" style="
            background: ${i.SAFE_GREEN};
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
          ">${p.OVERLAY_CLOSE}</button>
        </div>
      </div>
    </div>
  `;let y=a.querySelector("#semd-overlay-proceed"),h=a.querySelector("#semd-overlay-close");return y?.addEventListener("click",()=>{o(),s()}),h?.addEventListener("click",()=>{n()}),a}function E(t){s();let e=v(t);document.body?document.body.appendChild(e):document.addEventListener("DOMContentLoaded",()=>{document.body.appendChild(e)})}function s(){let t=document.getElementById(g);t&&t.remove()}var d={CHECK_URL:"CHECK_URL",URL_RESULT:"URL_RESULT",SHOW_OVERLAY:"SHOW_OVERLAY",DISMISS_OVERLAY:"DISMISS_OVERLAY",GET_AUTH_STATUS:"GET_AUTH_STATUS",VALIDATE_ACCESS_CODE:"VALIDATE_ACCESS_CODE",LOGOUT:"LOGOUT"};console.log("[SEMD] Content script loaded");var u=class{currentUrl="";observer=null;constructor(){this.init()}init(){this.currentUrl=this.getCurrentUrl(),this.checkUrl(this.currentUrl),this.startUrlMonitor(),this.listenForMessages()}getCurrentUrl(){return window.location.href}async checkUrl(e){console.log(`[SEMD] Checking URL: ${e}`),l.sendMessage({type:d.CHECK_URL,url:e},r=>{let o=l.getLastError();if(o){console.warn("[SEMD] Message error:",o.message);return}r?.success&&r.data?.result?.isMalicious&&this.handleMaliciousUrl(e,r.data.result)})}handleMaliciousUrl(e,r){console.log("[SEMD] Malicious URL detected:",e),E({url:e,accuracy:r.accuracy,onProceed:()=>{console.log("[SEMD] User chose to proceed"),s()},onClose:()=>{console.log("[SEMD] User chose to close tab"),l.sendMessage({type:d.DISMISS_OVERLAY,action:"close"}),window.close()}})}startUrlMonitor(){window.addEventListener("popstate",()=>this.onUrlChange()),window.addEventListener("hashchange",()=>this.onUrlChange());let e=history.pushState.bind(history),r=history.replaceState.bind(history);history.pushState=(...o)=>{e(...o),this.onUrlChange()},history.replaceState=(...o)=>{r(...o),this.onUrlChange()},this.observer=new MutationObserver(()=>{this.currentUrl!==window.location.href&&this.onUrlChange()}),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0})}onUrlChange(){let e=this.getCurrentUrl();e!==this.currentUrl&&(console.log(`[SEMD] URL changed: ${this.currentUrl} -> ${e}`),this.currentUrl=e,s(),this.checkUrl(e))}listenForMessages(){l.onMessage.addListener((e,r,o)=>{let n=e;return n.type===d.SHOW_OVERLAY&&n.url&&(E({url:n.url,accuracy:n.accuracy||0,onProceed:()=>s(),onClose:()=>window.close()}),o({success:!0})),n.type===d.DISMISS_OVERLAY&&(s(),o({success:!0})),!0})}destroy(){this.observer&&(this.observer.disconnect(),this.observer=null),s()}};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>new u):new u;})();
